const Discord = require("discord.js");
const Store = require('data-store');
var splitArray = require('split-array');
const wins = new Store({ path: 'wins.json' });
const client = new Discord.Client();
client.on("ready", () => {
  console.log("Bot Active.");
});
client.on('message', function(message) {
	if(message.content.startsWith('!win')){
		if(message.mentions.members.first()!==undefined){
			if(wins.hasOwn(message.mentions.members.first().id)){
				var cw = wins.get(message.mentions.members.first().id)
				cw.wins=cw.wins+1
				wins.set(message.mentions.members.first().id, cw)
			}else{
				wins.set(message.mentions.members.first().id, {id: message.mentions.members.first().id, wins: 1, losses: 0})
			}
			message.channel.send(message.author + ' gave '+message.mentions.members.first()+' 1 win.')
		}else{
			message.channel.send('Command incorrect. Usage: !win @name')
		}
	}else if(message.content.startsWith('!loss')){
		if(message.mentions.members.first()!==undefined){
			if(wins.hasOwn(message.mentions.members.first().id)){
				var cw = wins.get(message.mentions.members.first().id)
				cw.losses=cw.losses+1
				wins.set(message.mentions.members.first().id, cw)
			}else{
				wins.set(message.mentions.members.first().id, {id: message.mentions.members.first().id, wins: 0, losses: 1})
			}
			message.channel.send(message.author + ' gave '+message.mentions.members.first()+' 1 loss.')
		}else{
			message.channel.send('Command incorrect. Usage: !loss @name')
		}
	}else if(message.content.startsWith('!ranking')){
		var data = wins.clone()
		var dArr = []
		var sortArr = []
		Object.keys(data).forEach(function(key) {
		  var val = data[key];
		  sortArr.push(val)
		});
		sortArr.sort(function (a, b) {
		  return (b.wins-b.losses) - (a.wins-a.losses)
		});
		sortArr.forEach(function(val){
			dArr.push('<@'+val.id+'> | Wins: '+val.wins+' | Losses: '+val.losses+' | Total: '+(val.wins-val.losses))
		})
		var sArr = splitArray(dArr, 20)
		sArr.forEach(function(page){
			var pstring = page.join('\n')
			const embed = {
			  "title": "Current Rankings",
			  "description": pstring,
			  "color": 1863843,
			  "timestamp": new Date()
			};
			message.channel.send({ embed });
		})
		if(sArr.length===0){message.channel.send('No users currently have wins/losses.')}
	}
})
process.on('unhandledRejection', (reason, p) => {
  console.log('Unhandled Rejection at: Promise', p, 'reason:', reason);
});
client.login("NTMxMTk5NTQ5MTA5MTc0MzAy.DxKdww.9diADRC7cub1Y5eryCdA-cB-JZk");
